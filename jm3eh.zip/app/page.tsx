import {
  Award,
  Landmark,
  BookOpen,
  Users,
  Palette,
  Image,
  FileText,
  FileImage,
  CreditCard,
  MapPin,
  MessageCircle,
} from "lucide-react"
import { PortalHeader } from "@/components/portal-header"
import { FileSection } from "@/components/file-section"
import { FileButton } from "@/components/file-button"

export default function Page() {
  return (
    <main className="min-h-screen bg-background px-5 py-10">
      <div className="mx-auto max-w-3xl rounded-3xl bg-card p-8 shadow-[0_10px_30px_oklch(0_0_0_/_0.06)] sm:p-10">
        <PortalHeader />

        <FileSection title={"\u0627\u0644\u0648\u062B\u0627\u0626\u0642 \u0627\u0644\u0631\u0633\u0645\u064A\u0629 \u0648\u0627\u0644\u062A\u0631\u0627\u062E\u064A\u0635"}>
          <FileButton
            label={"\u0634\u0647\u0627\u062F\u0629 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062C\u0645\u0639\u064A\u0629"}
            href="#"
            icon={Award}
          />
          <FileButton
            label={"\u0642\u0631\u0627\u0631 \u0627\u0644\u062A\u0623\u0633\u064A\u0633"}
            href="#"
            icon={Landmark}
          />
          <FileButton
            label={"\u0627\u0644\u0644\u0627\u0626\u062D\u0629 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629"}
            href="#"
            icon={BookOpen}
          />
          <FileButton
            label={"\u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u0639\u0644\u0649 \u0645\u062C\u0644\u0633 \u0627\u0644\u0625\u062F\u0627\u0631\u0629"}
            href="#"
            icon={Users}
          />
        </FileSection>

        <FileSection title={"\u0627\u0644\u0647\u0648\u064A\u0629 \u0627\u0644\u0628\u0635\u0631\u064A\u0629 \u0648\u0627\u0644\u0645\u0631\u0627\u0633\u0644\u0627\u062A"}>
          <FileButton
            label={"\u0628\u0646\u0627\u0621 \u0627\u0644\u0647\u0648\u064A\u0629 \u0627\u0644\u0628\u0635\u0631\u064A\u0629 (\u0627\u0644\u062F\u0644\u064A\u0644)"}
            href="#"
            icon={Palette}
          />
          <FileButton
            label={"\u0634\u0639\u0627\u0631 \u0627\u0644\u062C\u0645\u0639\u064A\u0629 (Logo)"}
            href="#"
            icon={Image}
          />
          <FileButton
            label={"\u0648\u0631\u0642 \u0631\u0633\u0645\u064A (\u0635\u064A\u063A\u0629 Word)"}
            href="#"
            icon={FileText}
          />
          <FileButton
            label={"\u0648\u0631\u0642 \u0631\u0633\u0645\u064A (\u0635\u064A\u063A\u0629 \u0635\u0648\u0631\u0629)"}
            href="#"
            icon={FileImage}
          />
        </FileSection>

        <FileSection title={"\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062C\u0645\u0639\u064A\u0629 \u0648\u0627\u0644\u062A\u0648\u0627\u0635\u0644"}>
          <FileButton
            label={"\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062D\u0633\u0627\u0628 \u0627\u0644\u0628\u0646\u0643\u064A"}
            href="#"
            icon={CreditCard}
          />
          <FileButton
            label={"\u0627\u0644\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0648\u0637\u0646\u064A \u0648\u0645\u0642\u0631 \u0627\u0644\u062C\u0645\u0639\u064A\u0629"}
            href="/national-address"
            icon={MapPin}
          />
          <FileButton
            label={"\u0642\u0646\u0648\u0627\u062A \u0627\u0644\u062A\u0648\u0627\u0635\u0644"}
            href="/contact"
            icon={MessageCircle}
          />
        </FileSection>
      </div>
    </main>
  )
}
